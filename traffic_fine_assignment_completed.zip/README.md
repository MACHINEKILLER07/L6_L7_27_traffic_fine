# L6_L7_27: Traffic Fine Calculator

## Lab 6: Code and Branch Coverage

### Overview
This project tests a Python traffic fine calculator with pytest. The module calculates speeding fines by road zone, determines licence actions from penalty points, and totals fines with a maximum cap.

### Files
- `traffic_fine.py`: implementation under test.
- `test_traffic_fine.py`: pytest test suite covering normal cases, threshold boundaries, branch alternatives, and error handling.

### Setup
```bash
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\\Scripts\\activate
python -m pip install pytest coverage
```

### Run tests
```bash
python -m pytest -v
```

### Measure statement and branch coverage
```bash
coverage run --branch -m pytest
coverage report -m
```

### Test coverage design
- `speeding_fine`: no speeding; school, highway, and default zones; exactly 20 and 40 km/h above the limit; and the greater-than-20 / greater-than-40 fine multipliers.
- `license_action`: below 4 points, 4-7, 8-11 for repeat and non-repeat offenders, and 12+ for commercial and non-commercial licences.
- `total_penalty`: empty and ordinary lists, exact cap, cap exceeded, and negative fine rejection.

The test suite intentionally tests boundary values because the implementation uses strict `>` comparisons for speeding thresholds and `>=` comparisons for licence thresholds.
