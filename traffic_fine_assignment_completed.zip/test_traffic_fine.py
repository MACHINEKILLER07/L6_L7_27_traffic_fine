import pytest

from traffic_fine import speeding_fine, license_action, total_penalty


# -------------------- speeding_fine --------------------

def test_no_speeding():
    assert speeding_fine(50, 60, "city") == 0


@pytest.mark.parametrize(
    ("speed", "limit", "zone", "expected"),
    [
        (61, 60, "school", 2000),
        (61, 60, "highway", 1000),
        (61, 60, "city", 500),
        (80, 60, "city", 500),       # exactly 20 over
        (81, 60, "city", 1000),      # more than 20 over
        (100, 60, "city", 1000),     # exactly 40 over
        (101, 60, "city", 1500),     # more than 40 over
        (101, 60, "school", 6000),
        (101, 60, "highway", 3000),
    ],
)
def test_speeding_fine_rates(speed, limit, zone, expected):
    assert speeding_fine(speed, limit, zone) == expected


def test_speed_equal_to_limit():
    assert speeding_fine(60, 60, "highway") == 0


# -------------------- license_action --------------------

def test_clean_record():
    assert license_action(2, False, False) == "none"


@pytest.mark.parametrize(
    ("points", "is_commercial", "repeat_offender", "expected"),
    [
        (4, False, False, "notice"),
        (7, False, False, "notice"),
        (8, False, False, "warning"),
        (8, False, True, "suspend"),
        (11, True, False, "warning"),
        (12, False, False, "suspend"),
        (12, True, False, "revoke"),
        (20, True, True, "revoke"),
        (3, True, True, "none"),
    ],
)
def test_license_action_thresholds(points, is_commercial, repeat_offender, expected):
    assert license_action(points, is_commercial, repeat_offender) == expected


# -------------------- total_penalty --------------------

def test_total_penalty_empty_list():
    assert total_penalty([]) == 0


def test_total_penalty_sum():
    assert total_penalty([100, 200, 300]) == 600


def test_total_penalty_exact_cap():
    assert total_penalty([4000, 6000]) == 10000


def test_total_penalty_capped():
    assert total_penalty([6000, 5000]) == 10000


def test_total_penalty_rejects_negative_fine():
    with pytest.raises(ValueError, match="negative fine"):
        total_penalty([100, -1, 200])
